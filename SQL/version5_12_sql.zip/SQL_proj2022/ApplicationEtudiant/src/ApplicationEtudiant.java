import java.sql.*;
import java.util.Scanner;

public class ApplicationEtudiant {

  // private String url = "jdbc:postgresql://172.24.2.6:5432/nomDB";  //remplacer le nom de la db ici
  private String url = "jdbc:postgresql://localhost:5432/postgres";
  private Connection conn = null;

  private PreparedStatement psConn1 = null;
  private PreparedStatement psConn2 = null;
  private PreparedStatement ps1 = null;
  private PreparedStatement ps2 = null;
  private PreparedStatement ps3 = null;
  private PreparedStatement ps4 = null;
  private PreparedStatement ps5 = null;
  private PreparedStatement ps6 = null;

  private Scanner scanner = new Scanner(System.in);
  private int idEtudiant;

  public ApplicationEtudiant() {
    try {
      Class.forName("org.postgresql.Driver");
    } catch (ClassNotFoundException e) {
      System.out.println("Driver PostgreSQL manquant !");
      System.exit(1);
    }

    try {
      conn = DriverManager.getConnection(url, "laurentvandermeersch", "123");
    } catch (SQLException e) {
      e.printStackTrace();
      System.out.println("Impossible de joindre le server !");
      System.exit(1);
    }

    try {
      psConn1 = conn.prepareStatement("SELECT projet.recupererIdEtudiant(?);");
      psConn2 = conn.prepareStatement("SELECT projet.recupererMdpEtudiant(?);");
      ps1 = conn.prepareStatement("");
      ps2 = conn.prepareStatement("");
      ps3 = conn.prepareStatement("");
      ps4 = conn.prepareStatement("");
      ps5 = conn.prepareStatement("");
      ps6 = conn.prepareStatement("");
    } catch (SQLException e) {
      System.out.println("Erreur lors de l’insertion !");
      System.exit(1);
    }
  }

  //etudiant entre son adresse mail, ensite son mdp
  public void connexion(){
    do {
      System.out.println("Entrez votre mail etudiant : ");
      String mail = scanner.next();
      System.out.println("Entrez votre mot de passe : ");
      String mdp = scanner.next();
      if(BCrypt.checkpw(mdp,recupererMdpEtudiant(mail)))
        idEtudiant = recupererIdEtudiant(mail);
      else {
        System.out.println("mdp incorrect reessayez");
      }
    } while(idEtudiant == 0);
  }

  public int recupererIdEtudiant(String mail) {
    int i = 0;
    try {
      psConn1.setString(1, mail);
      ResultSet rs = psConn1.executeQuery();
      while(rs.next()) {
        i = rs.getInt(1);
      }
    } catch (SQLException se) {
      System.out.println("Erreur lors de la connexion !");
      se.printStackTrace();
      System.exit(1);
    }
    return i;
  }
  public String recupererMdpEtudiant(String mail) {
    String s = null;
    try {
      psConn2.setString(1, mail);
      ResultSet rs = psConn2.executeQuery();
      while(rs.next()) {
        s = rs.getString(1);
      }
    } catch (SQLException se) {
      System.out.println("Erreur lors de la connexion !");
      se.printStackTrace();
      System.exit(1);
    }
    return s;
  }
}
